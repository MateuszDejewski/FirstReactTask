function Head() {
	return (<h1>Lista zadań PSW</h1>);
}

export default Head